<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2018

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'PDFCrowdWriter for Commerce
------------------------

Adds a PDF Writer that Commerce can use to generate PDFs (like invoices), based on the PDFCrowd v2 API.


',
    'changelog' => '++ PDFCrowdWriter for Commerce 1.0.0-pl
++ Released on 2019-03-26
++++++++++++++++++++++++++
- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ebefea17e3d47b20a0de05b733e5a443',
      'native_key' => 'commerce_pdfcrowdwriter',
      'filename' => 'modNamespace/a8365940140ed3b0c0334ac1816caed6.vehicle',
      'namespace' => 'commerce_pdfcrowdwriter',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '118c5d82bc098f9b19a6f2a899625d6a',
      'native_key' => '118c5d82bc098f9b19a6f2a899625d6a',
      'filename' => 'xPDOFileVehicle/bdaa40af6d3861e7f6e84f05cc3e9b18.vehicle',
    ),
  ),
);